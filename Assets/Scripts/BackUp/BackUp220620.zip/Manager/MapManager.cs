using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class MapManager {
    Tilemap _tilemap;
    GameObject _map;
    public GameObject LoadMap(int mapId) {
        string mapName = "Map_" + mapId.ToString("000");

        GameObject go = Resources.Load<GameObject>($"Prefabs/Maps/{mapName}");
        

        if (go != null) {
            _map = Object.Instantiate(go);

            return _map;
        }

        return null;
    }

    public float CollisionDistCheck(GameObject map, Transform transform) {
        TilemapCollider2D _mapcollider;
        float _dist = 100.0f;
        _mapcollider = map.GetComponentInChildren<TilemapCollider2D>();

        if (_mapcollider != null) {
            _dist = (_mapcollider.bounds.SqrDistance(transform.position));
            if (_dist < 0.2f) {
                return _dist;
            }
        }

        return _dist;
    }

    // tilemap 통해서 오브젝트 인식하는 방법 없을까 해당 그리드는 못 들어가게?
    public void CheckCollsioni() {
        _tilemap = _map.GetComponent<Tilemap>();

        //_tilemap.
    }
}