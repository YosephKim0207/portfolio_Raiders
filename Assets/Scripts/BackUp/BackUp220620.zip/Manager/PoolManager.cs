using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PoolManager {

    class Pool {
        Stack _poolStack = new Stack();

        // initNum만큼 Pool에 child Push하는 초기화 진행
        public void Init(GameObject originObj, GameObject parentObj, int initNum = 5) {
            for (int i = 0; i < initNum; ++i) {
                GameObject childObj = Object.Instantiate(originObj, parentObj.transform);
                childObj.name = $"{originObj.name}";
                childObj.SetActive(false);
                _poolStack.Push(childObj);
            }
        }

        // child를 만들어 parentObj 하위에 위치시키고 pool용 Stack에 Push
        // _poolStack이 비어있으면 Instantiate 후 push, 아니면 그냥 push되게 해야..
        // [Fixed] Problem 01 : push에서 stack 초기화 오류 발생
        // [Fixed] Problem 02 : Instantiate시 이름에 원래 Clone 붙어있었나? clone이 있다면
        // PushPoolChild에서 pool 찾는 방법도 바뀌어야 함 확인 필요
        // [sol] Instantiate 이후 childObj의 이름 변경해줌 
        public void Push(GameObject originObj, GameObject parentObj = null) {
            originObj.SetActive(false);
            _poolStack.Push(originObj);
        }

        // pool용 Stack에서 Obj Pop시키고 활성화 시켜 return
        public GameObject Pop() {
            GameObject childObj = (GameObject)_poolStack.Pop();
            childObj.SetActive(true);
            return childObj;
        }

        public int Count() {
            return _poolStack.Count;
        }
    }

    // Obj당 Pool들 관리
    Dictionary<string, Pool> _poolDic = new Dictionary<string, Pool>();    
    GameObject _root;

    // !!! 꼭 필요한지 더 고민해보기 
    public void Init() {
        if(_root == null) {
            _root = new GameObject("@RootPool");
            Object.DontDestroyOnLoad(_root);
        }
    }

    public GameObject UsePool(GameObject originObj) {

        // !!! Find의 성능은? 대체할 수 있는 방법은 없을까?
        GameObject parentObj = GameObject.Find(originObj.name);  

        // Pool 존재유무 확
        // Pool의 Parent가 없는 경우
        if(parentObj == null) {
            // 해당 Obj의 Pool을 위한 Stack 만들기
            Pool pool = new Pool();

            // Pooling된 Obj들이 들어갈 부모 Obj 만들/
            // !!! 해당 Pool이 @RootPool 하위로 들어가도록 수정하기 
            parentObj = new GameObject(originObj.name);
            parentObj.transform.parent = _root.transform;

            // 새로 생긴 parentObj 초기화
            pool.Init(originObj, parentObj);
           
            // 원본obj이름을 key로 딕셔너리에 Stack add
            _poolDic.Add(originObj.name, pool);

            return PopPoolChild(originObj, parentObj);
        }
        // Pool Parent가 있는 경우 
        else {
            return PopPoolChild(originObj, parentObj);
        }

    }

    // Pool에서 Obj pop하여 사용하기 
    public GameObject PopPoolChild(GameObject originObj, GameObject parentObj) {
        
        // 해당 오브젝트의 pool이 없는 경우 - parentObj가 있는데 이럴 경우가 있나?
        if (_poolDic.ContainsKey(originObj.name).Equals(false)) {
            // 해당 오브젝트가 pool로 사용할 오브젝트인지 확인
            // pool 오브젝트가 아닌 경우 
            //if (false) {
            //    // 이 위치는 일단 bullet 기준이므로 추후 수정될 수 있음 
            //    GameObject go = Object.Instantiate(originObj);
            //    Debug.Log("PopPoolChild_ContainsKey : False");
            //    return go;
            //}
            // pool 오브젝트인 경우
            {
                Debug.Log("PopPoolChild_ContainsKey : True");

                Pool pool = new Pool();
                pool.Init(originObj, parentObj);
                _poolDic.Add(originObj.name, pool);
                return pool.Pop();
            }

        }
        // 해당 오브젝트의 pool이 있는 경우 
        else {
            Pool pool = _poolDic[originObj.name];

            // 비활성화 된 Obj가 남아있는 경우
            if (!pool.Count().Equals(0)) {
                return pool.Pop();
            }
            // 비활성화 된 Obj가 남아있지 않은 경우
            else {
                // Obj를 Pool에 추가 생성(Init을 이용) 및 Pop
                pool.Init(originObj, parentObj, 1);
                return pool.Pop();
            }
        }
    }

    // 사용한 오브젝트를 PoolRoot에 반환 
    public void PushPoolChild(GameObject childObj) {
        Pool pool = _poolDic[childObj.name];
        childObj.SetActive(false);
        pool.Push(childObj);
    }

    // Pool 제거
    public void DeletePool() {

    }

}
