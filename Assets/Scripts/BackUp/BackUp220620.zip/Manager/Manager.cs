using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Manager : MonoBehaviour {
    static Manager s_instance;
    static Manager Instance { get { Init(); return s_instance; } }

    PoolManager _pool = new PoolManager();
    DataManager _data = new DataManager();

    public static PoolManager Pool {get { return Instance._pool; } }
    public static DataManager Data { get { return Instance._data; } }

    private void Start() {
        Init();
    }

    static void Init() {
        if (s_instance == null) {
            GameObject go = GameObject.Find("@Manager");
            if (go == null) {
                go = new GameObject { name = "@Manager" };
                go.AddComponent<Manager>();

                
            }

            DontDestroyOnLoad(go);
            s_instance = go.GetComponent<Manager>();

            s_instance._pool.Init();
            s_instance._data.Init();

        }
    }
}
