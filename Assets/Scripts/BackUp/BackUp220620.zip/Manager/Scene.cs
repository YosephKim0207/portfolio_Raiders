using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Scene : MonoBehaviour
{
    private void Awake() {
        Init();
    }

    protected virtual void Init() {
        GameObject go = Resources.Load<GameObject>("Prefabs/Player");
        GameObject player = Object.Instantiate<GameObject>(go);


    }
}
