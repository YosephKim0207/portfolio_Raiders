using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnumList {
    public enum CreatureState {
        Idle,
        Move,
        Attack,
        Jump,
        Damaged,
    }

    public enum CreatureDir {
        Up,
        Down,
        Left,
        Right,
        UpLeft,
        UpRight,
        DownLeft,
        DownRight,
        None,
    }

}
