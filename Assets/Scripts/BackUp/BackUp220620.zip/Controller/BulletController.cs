using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletController : CreatureController {
    // [Fixed] problem 01 : 발사 때 반작용
    // sol : 반작용이 아니었음. Attack과 Movig 동시 작동이 가능하도록 하면서 Moving에서 저장된 마지막 dir으로 이동하던 것이었음
    // 움직임의 마지막은 방향이 None이 되도록 수정함
    // [Fixed] problem 02 : 총알 생성 회전방향 이상함
    // problem 03 : collsion이 체크되지 않는 경우도 있음(collsion이 얇아서)

    // [Fixed] problem 04 : bullet이 마우스 위치대로 이동 안 함
    // [sol] : bullet이 최초 init될 때만 마우스 위치로 방향 가져옴
    //         setActive(true)될 때마다 방향 설정해야
    //         >> OnEnbale()함수는 오브젝트가 활성화 될 때마다 실행된다
    //         >> SetBulletRotation()을 OnEnable()로 옯기기 
    
    protected override void Init() {
        _rigidbody = GetComponent<Rigidbody2D>();
        //SetBulletRotation();
    }
    private void OnEnable() {
        SetBulletRotation();
    }

    protected override void UpdateIdle() {
        
    }
    // [Fixed] Problem : _desPos is not holding
    protected override void UpdateMoving() {
        float _bulletSpeed = _speed * 2.0f;
        _rigidbody.MovePosition(transform.position + _destPos * _bulletSpeed * Time.fixedDeltaTime);
        Vector3 bullPos = Camera.main.WorldToViewportPoint(transform.position);
        if(bullPos.x <= -0.05f || bullPos.x >= 1.05f || bullPos.y <= -0.05f || bullPos.y >= 1.05f) {
            Manager.Pool.PushPoolChild(gameObject);
        }
    }

    protected virtual void SetBulletRotation() {
        _destPos = shootDir.normalized;
        State = EnumList.CreatureState.Move;
        float angle = Mathf.Atan2(_destPos.y, _destPos.x) * Mathf.Rad2Deg;  // target에 대한 xy방향벡터를 통해 tan 각도 구하기
        transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);  //Z축 중심으로 angle만큼 회전
    }
    private void OnTriggerEnter2D(Collider2D collision) {
        if (collision.gameObject.layer.Equals(6)) {
            return;
        }

        Manager.Pool.PushPoolChild(gameObject);
        
    }
}
