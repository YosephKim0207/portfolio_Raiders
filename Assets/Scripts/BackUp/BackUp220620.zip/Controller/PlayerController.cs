using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static EnumList;

public class PlayerController : CreatureController {
    GameObject go;
    GameObject _hand;
    GameObject _mouse;


    protected override void Init() {
        base.Init();

        //Test
        GameObject _map;
        MapManager _mapManager = new MapManager();
        _map = _mapManager.LoadMap(001);

        go = Resources.Load<GameObject>("Prefabs/Player_Gun_Hand");
        if (go != null) {
            _hand = Object.Instantiate(go, transform);
            _hand.name = "Player_Hand";
            _hand.transform.position = new Vector3(-0.3f, -0.3f, 0.0f);
        }

        go = Resources.Load<GameObject>("Prefabs/Mouse");
        if (go != null) {
            _mouse = Object.Instantiate(go, Vector3.zero, Quaternion.Euler(Vector3.zero));
        }
    }

    void LateUpdate() {
        Camera.main.transform.position = new Vector3(transform.position.x, transform.position.y, -10.0f);    
    }

    protected override void UpdateController() {
        _hand.transform.position = transform.position + new Vector3(-0.3f, -0.3f, 0.0f);

        switch (State) {
            case CreatureState.Idle:
                GetDir();
                break;
            case CreatureState.Move:
                GetDir();
                break;
            case CreatureState.Attack:
                break;
            case CreatureState.Damaged:
                break;
        }

        MouseTracking();

        base.UpdateController();
    }

    // (Fixed) Problem 1 : ??? ??? ?? ??? 1?? ? (?? ? ???? ??)
    // sol 1-1 : normalized
    // (Fixed) Problem 2-1 : ? / ?? ?? ? ? / ?? ??? ?? ????? ?? ? ?? ??
    // sol 2-1 : ????? flip ??
    // (OnGoing) Problem 3 : ??/???? ???????? ???? ???? ?????? ?????? ?????? ?? ????. ???? ????
    // sol 3 :
    void GetDir() {

        if (Input.GetKey(KeyCode.W)) {
            MoveDir = CreatureDir.Up;

            if (Input.GetKey(KeyCode.A)) {
                MoveDir = CreatureDir.UpLeft;
            }
            else if (Input.GetKey(KeyCode.D)) {
                MoveDir = CreatureDir.UpRight;
            }
        }
        else if (Input.GetKey(KeyCode.S)) {
            MoveDir = CreatureDir.Down;

            if (Input.GetKey(KeyCode.A)) {
                MoveDir = CreatureDir.DownLeft;
            }
            else if (Input.GetKey(KeyCode.D)) {
                MoveDir = CreatureDir.DownRight;
            }
        }
        else if (Input.GetKey(KeyCode.A)) {
            MoveDir = CreatureDir.Left;
        }
        else if (Input.GetKey(KeyCode.D)) {
            MoveDir = CreatureDir.Right;
        }
        else {
            MoveDir = CreatureDir.None;
        }
    }

    protected override void UpdateMoving() {
        if (Input.GetKeyDown(KeyCode.Space)) {
            _makeJump = true;
        }

        base.UpdateMoving();
    }

    protected override void UpdateJump() {
        // Problem : 현재 손 제거 안 되는 중(Creature에서 사용할 때는 됐는데 왤까?)
        // Player 손 제거
        Transform child = transform.GetChild(0);
        child.gameObject.SetActive(false);

        base.UpdateJump();

        _makeJump = false;

        // Player 손 복구
        child.gameObject.SetActive(true);
    }

    // problem : 화면 이동시 딜레이 있음
    // problem : 딜레이로 인한 마우스 떨림 현상
    void MouseTracking() {

        // Problem : need to fix position z > No Hard Coding!
        _mouse.transform.position = Camera.main.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y, 10.0f));

        // Problem 01 : When Attack. Player Can't Move
        if (Input.GetMouseButton(0)) {
            if(State.Equals(CreatureState.Idle) || State.Equals(CreatureState.Move)) {
                State = CreatureState.Attack;
            }
        }

        if (Input.GetMouseButtonUp(0)) {
            State = CreatureState.Idle;
        }
    }

    protected override void UpdateAttack() {
        // (Fixed)Problem 01 : Not Instaniate
        // (FIxed)Problem 02 : Too Many Shoot Once(need too decrease)
        _target = _mouse;
        base.UpdateAttack();

    }

}