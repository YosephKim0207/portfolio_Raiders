using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GunController : MonoBehaviour {
    public bool equip = false;

    protected void Init() {
        
    }

    protected void Stat() {

    }

    protected void Shooting() {
        


    }

    protected void RotateGun() {

    }
}
